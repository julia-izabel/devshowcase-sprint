package com.devshowcase.dto;

import com.devshowcase.entity.Feedback;

import java.time.LocalDateTime;

public record FeedbackResponseDTO(
        Long id,
        Integer rating,
        String comment,
        LocalDateTime createdAt,
        Double projectAverageRating
) {
    public static FeedbackResponseDTO fromEntity(Feedback feedback) {
        return new FeedbackResponseDTO(
                feedback.getId(),
                feedback.getRating(),
                feedback.getComment(),
                feedback.getCreatedAt(),
                feedback.getProject().getAverageRating()
        );
    }
}
