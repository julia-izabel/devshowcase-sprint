package com.devshowcase.dto;

import com.devshowcase.entity.Project;

public record ProjectResponseDTO(
        Long id,
        String name,
        String description,
        String technology,
        Long upvotes,
        Double averageRating
) {
    public static ProjectResponseDTO fromEntity(Project project) {
        return new ProjectResponseDTO(
                project.getId(),
                project.getName(),
                project.getDescription(),
                project.getTechnology(),
                project.getUpvotes(),
                project.getAverageRating()
        );
    }
}
