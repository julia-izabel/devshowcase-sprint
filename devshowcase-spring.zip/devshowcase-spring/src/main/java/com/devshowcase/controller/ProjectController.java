package com.devshowcase.controller;

import com.devshowcase.dto.FeedbackRequestDTO;
import com.devshowcase.dto.FeedbackResponseDTO;
import com.devshowcase.dto.ProjectResponseDTO;
import com.devshowcase.service.ProjectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/projects")
@Tag(name = "Projects", description = "Endpoints de projetos do DevShowcase")
public class ProjectController {

    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @Operation(summary = "Lista projetos com filtro por tecnologia e paginação")
    @GetMapping
    public ResponseEntity<Page<ProjectResponseDTO>> listProjects(
            @RequestParam(required = false) String technology,
            @PageableDefault(size = 10) Pageable pageable) {
        return ResponseEntity.ok(projectService.findProjects(technology, pageable));
    }

    @Operation(summary = "Cadastra um feedback (nota de 1 a 5 + comentário) e atualiza a média do projeto")
    @PostMapping("/{id}/feedbacks")
    public ResponseEntity<FeedbackResponseDTO> addFeedback(
            @PathVariable Long id,
            @Valid @RequestBody FeedbackRequestDTO request) {
        FeedbackResponseDTO response = projectService.addFeedback(id, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @Operation(summary = "Incrementa o upvote (curtida) de um projeto")
    @PutMapping("/{id}/upvote")
    public ResponseEntity<ProjectResponseDTO> upvote(@PathVariable Long id) {
        return ResponseEntity.ok(projectService.upvote(id));
    }
}
