package com.devshowcase.service;

import com.devshowcase.dto.FeedbackRequestDTO;
import com.devshowcase.dto.FeedbackResponseDTO;
import com.devshowcase.dto.ProjectResponseDTO;
import com.devshowcase.entity.Feedback;
import com.devshowcase.entity.Project;
import com.devshowcase.exception.ResourceNotFoundException;
import com.devshowcase.repository.FeedbackRepository;
import com.devshowcase.repository.ProjectRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final FeedbackRepository feedbackRepository;

    public ProjectService(ProjectRepository projectRepository, FeedbackRepository feedbackRepository) {
        this.projectRepository = projectRepository;
        this.feedbackRepository = feedbackRepository;
    }

    @Transactional
    public FeedbackResponseDTO addFeedback(Long projectId, FeedbackRequestDTO dto) {
        Project project = findProjectOrThrow(projectId);

        Feedback feedback = Feedback.builder()
                .rating(dto.rating())
                .comment(dto.comment())
                .project(project)
                .build();

        feedbackRepository.save(feedback);
        project.getFeedbacks().add(feedback);

        // Regra de negócio: recalcula a média das notas do projeto
        double newAverage = project.getFeedbacks().stream()
                .mapToInt(Feedback::getRating)
                .average()
                .orElse(0.0);

        project.setAverageRating(Math.round(newAverage * 100.0) / 100.0);
        projectRepository.save(project);

        return FeedbackResponseDTO.fromEntity(feedback);
    }

    @Transactional
    public ProjectResponseDTO upvote(Long projectId) {
        Project project = findProjectOrThrow(projectId);
        project.setUpvotes(project.getUpvotes() + 1);
        projectRepository.save(project);
        return ProjectResponseDTO.fromEntity(project);
    }

    public Page<ProjectResponseDTO> findProjects(String technology, Pageable pageable) {
        Page<Project> page;
        if (technology != null && !technology.isBlank()) {
            page = projectRepository.findByTechnologyIgnoreCase(technology, pageable);
        } else {
            page = projectRepository.findAll(pageable);
        }
        return page.map(ProjectResponseDTO::fromEntity);
    }

    private Project findProjectOrThrow(Long id) {
        return projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Projeto com id " + id + " não encontrado"));
    }
}
